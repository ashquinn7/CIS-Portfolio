﻿namespace Lab4
{
    partial class gpaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.gpaTxt = new System.Windows.Forms.TextBox();
            this.gpaLbl = new System.Windows.Forms.Label();
            this.acceptRejectLbl = new System.Windows.Forms.Label();
            this.resultLbl = new System.Windows.Forms.Label();
            this.testLbl = new System.Windows.Forms.Label();
            this.testTxt = new System.Windows.Forms.TextBox();
            this.acceptedLbl = new System.Windows.Forms.Label();
            this.acceptedTotalLbl = new System.Windows.Forms.Label();
            this.rejectedLbl = new System.Windows.Forms.Label();
            this.rejectedTotalLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(32, 289);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(75, 23);
            this.calculateBtn.TabIndex = 0;
            this.calculateBtn.Text = "Calculate";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearBtn.Location = new System.Drawing.Point(176, 289);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 1;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // gpaTxt
            // 
            this.gpaTxt.Location = new System.Drawing.Point(149, 39);
            this.gpaTxt.Name = "gpaTxt";
            this.gpaTxt.Size = new System.Drawing.Size(100, 20);
            this.gpaTxt.TabIndex = 2;
            // 
            // gpaLbl
            // 
            this.gpaLbl.AutoSize = true;
            this.gpaLbl.Location = new System.Drawing.Point(64, 39);
            this.gpaLbl.Name = "gpaLbl";
            this.gpaLbl.Size = new System.Drawing.Size(60, 13);
            this.gpaLbl.TabIndex = 3;
            this.gpaLbl.Text = "Enter GPA:";
            // 
            // acceptRejectLbl
            // 
            this.acceptRejectLbl.AutoSize = true;
            this.acceptRejectLbl.Location = new System.Drawing.Point(12, 139);
            this.acceptRejectLbl.Name = "acceptRejectLbl";
            this.acceptRejectLbl.Size = new System.Drawing.Size(114, 13);
            this.acceptRejectLbl.TabIndex = 4;
            this.acceptRejectLbl.Text = "Accepted or Rejected:";
            // 
            // resultLbl
            // 
            this.resultLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultLbl.Location = new System.Drawing.Point(149, 138);
            this.resultLbl.Name = "resultLbl";
            this.resultLbl.Size = new System.Drawing.Size(100, 23);
            this.resultLbl.TabIndex = 5;
            // 
            // testLbl
            // 
            this.testLbl.AutoSize = true;
            this.testLbl.Location = new System.Drawing.Point(34, 89);
            this.testLbl.Name = "testLbl";
            this.testLbl.Size = new System.Drawing.Size(90, 13);
            this.testLbl.TabIndex = 6;
            this.testLbl.Text = "Enter Test Score:";
            // 
            // testTxt
            // 
            this.testTxt.Location = new System.Drawing.Point(149, 89);
            this.testTxt.Name = "testTxt";
            this.testTxt.Size = new System.Drawing.Size(100, 20);
            this.testTxt.TabIndex = 7;
            // 
            // acceptedLbl
            // 
            this.acceptedLbl.AutoSize = true;
            this.acceptedLbl.Location = new System.Drawing.Point(29, 192);
            this.acceptedLbl.Name = "acceptedLbl";
            this.acceptedLbl.Size = new System.Drawing.Size(83, 13);
            this.acceptedLbl.TabIndex = 8;
            this.acceptedLbl.Text = "Accepted Total:";
            // 
            // acceptedTotalLbl
            // 
            this.acceptedTotalLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.acceptedTotalLbl.Location = new System.Drawing.Point(15, 220);
            this.acceptedTotalLbl.Name = "acceptedTotalLbl";
            this.acceptedTotalLbl.Size = new System.Drawing.Size(100, 23);
            this.acceptedTotalLbl.TabIndex = 9;
            // 
            // rejectedLbl
            // 
            this.rejectedLbl.AutoSize = true;
            this.rejectedLbl.Location = new System.Drawing.Point(173, 192);
            this.rejectedLbl.Name = "rejectedLbl";
            this.rejectedLbl.Size = new System.Drawing.Size(80, 13);
            this.rejectedLbl.TabIndex = 10;
            this.rejectedLbl.Text = "Rejected Total:";
            // 
            // rejectedTotalLbl
            // 
            this.rejectedTotalLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rejectedTotalLbl.Location = new System.Drawing.Point(163, 220);
            this.rejectedTotalLbl.Name = "rejectedTotalLbl";
            this.rejectedTotalLbl.Size = new System.Drawing.Size(100, 23);
            this.rejectedTotalLbl.TabIndex = 11;
            // 
            // gpaForm
            // 
            this.AcceptButton = this.calculateBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearBtn;
            this.ClientSize = new System.Drawing.Size(327, 333);
            this.Controls.Add(this.rejectedTotalLbl);
            this.Controls.Add(this.rejectedLbl);
            this.Controls.Add(this.acceptedTotalLbl);
            this.Controls.Add(this.acceptedLbl);
            this.Controls.Add(this.testTxt);
            this.Controls.Add(this.testLbl);
            this.Controls.Add(this.resultLbl);
            this.Controls.Add(this.acceptRejectLbl);
            this.Controls.Add(this.gpaLbl);
            this.Controls.Add(this.gpaTxt);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.calculateBtn);
            this.Name = "gpaForm";
            this.Text = "Lab 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.TextBox gpaTxt;
        private System.Windows.Forms.Label gpaLbl;
        private System.Windows.Forms.Label acceptRejectLbl;
        private System.Windows.Forms.Label resultLbl;
        private System.Windows.Forms.Label testLbl;
        private System.Windows.Forms.TextBox testTxt;
        private System.Windows.Forms.Label acceptedLbl;
        private System.Windows.Forms.Label acceptedTotalLbl;
        private System.Windows.Forms.Label rejectedLbl;
        private System.Windows.Forms.Label rejectedTotalLbl;
    }
}

