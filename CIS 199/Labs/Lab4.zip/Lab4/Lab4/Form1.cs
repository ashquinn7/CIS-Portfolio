﻿// Grading ID: A7035
// Lab Number: Lab 4
// Due Date: 9/30/2018
// Course Section: CIS 199-01
// This form will figure out if a student's GPA and test scores will get them accepted or rejected to a University
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class gpaForm : Form
    {
        private int acceptedTotal; // This keeps the Accepted Totals Label private and allows a running total to occur
        private int rejectedTotal; // This keeps the Rejected Totals Label private and allows a runing total to occur

        public gpaForm()
        {
            InitializeComponent();
        }

        // This event handler will calculate if a GPA gets accepted or rejected
        private void calculateBtn_Click(object sender, EventArgs e)
        {
            double gpa; // This shows the inputed GPA value as a double
            int testScore; // This shows the inputed Test Score value as an integer

            double.TryParse(gpaTxt.Text, out gpa); // Gathers the input in the GPA textbox and tests for True or False with Try.Parse
            int.TryParse(testTxt.Text, out testScore); // Gather the input in the Test Score textbox and test for True or False with Try.Parse

            // This if statement tests if the gpa is greater than or equal to 3.0 AND if the test score is greater than or equal to 60 then you will be accepted
            // If not, then it will skip down to the next set of criteria
            if(gpa >= 3.0 && testScore >= 60)

            {
                resultLbl.Text = "Accepted"; // Displays accepted in the results label
                acceptedTotal = acceptedTotal + 1; // Adds the amount of people who were accepted and keeps it as a running total
                acceptedTotalLbl.Text = $"{acceptedTotal}"; // This will display how many people have been accepted in the label
            }

            // This else if statement says is the gpa is less than a 3.0 AND if the test score is greater than or equal to 80 then you will be accepted
            // If not, then it will skip down to the next set of criteria
            else if(gpa < 3.0 && testScore >= 80)

            {
                resultLbl.Text = "Accepted"; // Displays accepted in the results label
                acceptedTotal = acceptedTotal + 1; // Adds the amount of people who were accepted and keeps it as a running total
                acceptedTotalLbl.Text = $"{acceptedTotal}"; // This will display how many people have been accepted in the label

            }
            
            // This else statement says that if neither of the above if statements are true, then the student will be rejected
            else
            {
                resultLbl.Text = "Rejected"; // Displays rejected in the results label
                rejectedTotal = rejectedTotal + 1; // Adds the amount of people who were rejected and keeps it as a running total
                rejectedTotalLbl.Text = $"{rejectedTotal}"; // This will display how many people have been rejected in the label
            }
                
        }

        // This event handler will clear anything displayed in the form when I hit the escape key
        private void clearBtn_Click(object sender, EventArgs e)
        {
            gpaTxt.Text = ""; // Clears the gpa textbox
            testTxt.Text = ""; // Clears the test textbox
            resultLbl.Text = ""; // Clears the results textbox
            acceptedTotal = 0; // Returns the accepted total label to zero
            acceptedTotalLbl.Text = ""; // Clears the accepted total label
            rejectedTotal = 0; // Returns the rejected total label to zero
            rejectedTotalLbl.Text = ""; // Clears the rejected total label
        }
    }
}
