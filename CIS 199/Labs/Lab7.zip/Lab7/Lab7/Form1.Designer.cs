﻿namespace Lab7
{
    partial class Lab7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.futureValueLbl = new System.Windows.Forms.Label();
            this.annualLbl = new System.Windows.Forms.Label();
            this.numYearsLbl = new System.Windows.Forms.Label();
            this.valueLbl = new System.Windows.Forms.Label();
            this.calculateBtn = new System.Windows.Forms.Button();
            this.futureValueTxt = new System.Windows.Forms.TextBox();
            this.interestTxt = new System.Windows.Forms.TextBox();
            this.numYearsTxt = new System.Windows.Forms.TextBox();
            this.displayValueLbl = new System.Windows.Forms.Label();
            this.clearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // futureValueLbl
            // 
            this.futureValueLbl.AutoSize = true;
            this.futureValueLbl.Location = new System.Drawing.Point(34, 39);
            this.futureValueLbl.Name = "futureValueLbl";
            this.futureValueLbl.Size = new System.Drawing.Size(70, 13);
            this.futureValueLbl.TabIndex = 0;
            this.futureValueLbl.Text = "Future Value:";
            // 
            // annualLbl
            // 
            this.annualLbl.AutoSize = true;
            this.annualLbl.Location = new System.Drawing.Point(37, 86);
            this.annualLbl.Name = "annualLbl";
            this.annualLbl.Size = new System.Drawing.Size(107, 13);
            this.annualLbl.TabIndex = 1;
            this.annualLbl.Text = "Annual Interest Rate:";
            // 
            // numYearsLbl
            // 
            this.numYearsLbl.AutoSize = true;
            this.numYearsLbl.Location = new System.Drawing.Point(40, 138);
            this.numYearsLbl.Name = "numYearsLbl";
            this.numYearsLbl.Size = new System.Drawing.Size(89, 13);
            this.numYearsLbl.TabIndex = 2;
            this.numYearsLbl.Text = "Number of Years:";
            // 
            // valueLbl
            // 
            this.valueLbl.AutoSize = true;
            this.valueLbl.Location = new System.Drawing.Point(37, 188);
            this.valueLbl.Name = "valueLbl";
            this.valueLbl.Size = new System.Drawing.Size(76, 13);
            this.valueLbl.TabIndex = 3;
            this.valueLbl.Text = "Present Value:";
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(73, 287);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(75, 23);
            this.calculateBtn.TabIndex = 4;
            this.calculateBtn.Text = "Calculate";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // futureValueTxt
            // 
            this.futureValueTxt.Location = new System.Drawing.Point(207, 39);
            this.futureValueTxt.Name = "futureValueTxt";
            this.futureValueTxt.Size = new System.Drawing.Size(100, 20);
            this.futureValueTxt.TabIndex = 5;
            // 
            // interestTxt
            // 
            this.interestTxt.Location = new System.Drawing.Point(207, 86);
            this.interestTxt.Name = "interestTxt";
            this.interestTxt.Size = new System.Drawing.Size(100, 20);
            this.interestTxt.TabIndex = 6;
            // 
            // numYearsTxt
            // 
            this.numYearsTxt.Location = new System.Drawing.Point(207, 138);
            this.numYearsTxt.Name = "numYearsTxt";
            this.numYearsTxt.Size = new System.Drawing.Size(100, 20);
            this.numYearsTxt.TabIndex = 7;
            // 
            // displayValueLbl
            // 
            this.displayValueLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayValueLbl.Location = new System.Drawing.Point(207, 188);
            this.displayValueLbl.Name = "displayValueLbl";
            this.displayValueLbl.Size = new System.Drawing.Size(100, 23);
            this.displayValueLbl.TabIndex = 8;
            // 
            // clearBtn
            // 
            this.clearBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearBtn.Location = new System.Drawing.Point(207, 287);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 9;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // Lab7
            // 
            this.AcceptButton = this.calculateBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearBtn;
            this.ClientSize = new System.Drawing.Size(362, 419);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.displayValueLbl);
            this.Controls.Add(this.numYearsTxt);
            this.Controls.Add(this.interestTxt);
            this.Controls.Add(this.futureValueTxt);
            this.Controls.Add(this.calculateBtn);
            this.Controls.Add(this.valueLbl);
            this.Controls.Add(this.numYearsLbl);
            this.Controls.Add(this.annualLbl);
            this.Controls.Add(this.futureValueLbl);
            this.Name = "Lab7";
            this.Text = "Lab7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label futureValueLbl;
        private System.Windows.Forms.Label annualLbl;
        private System.Windows.Forms.Label numYearsLbl;
        private System.Windows.Forms.Label valueLbl;
        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.TextBox futureValueTxt;
        private System.Windows.Forms.TextBox interestTxt;
        private System.Windows.Forms.TextBox numYearsTxt;
        private System.Windows.Forms.Label displayValueLbl;
        private System.Windows.Forms.Button clearBtn;
    }
}

