﻿// Grading ID: A7035
// Lab Number: Lab 7
// Due Date: 11/11/2018
// Course Section: CIS 199-01
// This lab will calculate how much money you need to invest today to earn a certain amount in the future
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Lab7 : Form
    {
        public Lab7()
        {
            InitializeComponent();
        }

        // Precondition: Calculate button must be clicked or the enter button must be used
        // Postcondition: Will display the correct output value based on the three variables and after it has been returned in the next method
        private void calculateBtn_Click(object sender, EventArgs e)
        {
            double futureValue; // User input for future value of their investment
            double interestRate; // User input for interest rate
            int year; // User input for the amount of years

            if (double.TryParse(futureValueTxt.Text, out futureValue))
            {
                if (double.TryParse(interestTxt.Text, out interestRate))
                {
                    if (int.TryParse(numYearsTxt.Text, out year))
                    {
                        CalcPresentValue(futureValue, interestRate, year); // Value returning method
                        displayValueLbl.Text = CalcPresentValue(futureValue, interestRate, year).ToString($"C"); // This is the output after running through each method
                    }
                }
            } 
        }
        
        // Precondition: Each of the three input variables are declared and parsed and are in a value-returning method
        // Postcondition: The method will return the correct calculation for present value based on the three input variables
        public static double CalcPresentValue(double futureValue, double interestRate, int year)
        {
            double presentValue; // Output being declared in this method and returned to the private void method
            presentValue = futureValue / Math.Pow(1 + interestRate, year); // Calculation
            return presentValue; // Return the value to the previous method
        }

        // Precondition: Clear button must be enabled in the GUI and at least some text must be entered for anything to be deleted
        // Postcondition: Every textbox and label will be cleared
        private void clearBtn_Click(object sender, EventArgs e)
        {
            futureValueTxt.Text = ""; // Clears the textbox
            interestTxt.Text = ""; // Clears the textbox
            numYearsTxt.Text = ""; // Clears the textbox
            displayValueLbl.Text = ""; // Clears the label
        }
    }
}
