﻿// Grading ID: A7035
// Lab Number: Lab 3
// Due Date: 9/23/2018
// Class Section: CIS 199-01
// This Lab will calculate the diameter, surface area, and volume of a circle when given the radius.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class labForm : Form
    {
        public labForm()
        {
            InitializeComponent();
        }

        // This event handler will calculate and displays the diameter, surface area, and volume from the given raidus of a sphere.
        private void calculateBtn_Click(object sender, EventArgs e)
        {
            double radius; // This will allow me to enter any radius for a circle.
            double diameter; // This will calculate my diameter when given the radius.
            double surfaceArea; // This will calculate my surface area when given the radius.
            double volume; // This will calculate my volume when given the raidus.

            radius = double.Parse(radiusTxt.Text); // This tells my program to read the radius as a text.

            // This is all the math for my program. This calculates the diameter, surface area, and volume, with their given formulas.
            diameter = 2 * radius;
            surfaceArea = 4 * Math.PI * Math.Pow(radius, 2);
            volume = 4 * Math.PI * Math.Pow(radius, 3) / 3;

            // This tells my program to output my diameter, surface area, and volume in their specific labels and to have a percision of two decimal places.
            diameterLbl.Text = $"{diameter:F2}";
            surfaceLbl.Text = $"{surfaceArea:F2}";
            volumeLbl.Text = $"{volume:F2}";



            








        }
    }
}
