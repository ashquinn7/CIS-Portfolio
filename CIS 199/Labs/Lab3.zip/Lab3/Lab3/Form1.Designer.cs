﻿namespace Lab3
{
    partial class labForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(labForm));
            this.nameLbl = new System.Windows.Forms.Label();
            this.showDiameterLbl = new System.Windows.Forms.Label();
            this.showSurfaceLbl = new System.Windows.Forms.Label();
            this.showVolumeLbl = new System.Windows.Forms.Label();
            this.diameterLbl = new System.Windows.Forms.Label();
            this.surfaceLbl = new System.Windows.Forms.Label();
            this.volumeLbl = new System.Windows.Forms.Label();
            this.calculateBtn = new System.Windows.Forms.Button();
            this.topImage = new System.Windows.Forms.PictureBox();
            this.bottomImage = new System.Windows.Forms.PictureBox();
            this.radiusTxt = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.topImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bottomImage)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Location = new System.Drawing.Point(174, 64);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(92, 13);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "Radius of Sphere:";
            // 
            // showDiameterLbl
            // 
            this.showDiameterLbl.AutoSize = true;
            this.showDiameterLbl.Location = new System.Drawing.Point(40, 202);
            this.showDiameterLbl.Name = "showDiameterLbl";
            this.showDiameterLbl.Size = new System.Drawing.Size(52, 13);
            this.showDiameterLbl.TabIndex = 2;
            this.showDiameterLbl.Text = "Diameter:";
            // 
            // showSurfaceLbl
            // 
            this.showSurfaceLbl.AutoSize = true;
            this.showSurfaceLbl.Location = new System.Drawing.Point(20, 253);
            this.showSurfaceLbl.Name = "showSurfaceLbl";
            this.showSurfaceLbl.Size = new System.Drawing.Size(72, 13);
            this.showSurfaceLbl.TabIndex = 3;
            this.showSurfaceLbl.Text = "Surface Area:";
            // 
            // showVolumeLbl
            // 
            this.showVolumeLbl.AutoSize = true;
            this.showVolumeLbl.Location = new System.Drawing.Point(47, 303);
            this.showVolumeLbl.Name = "showVolumeLbl";
            this.showVolumeLbl.Size = new System.Drawing.Size(45, 13);
            this.showVolumeLbl.TabIndex = 4;
            this.showVolumeLbl.Text = "Volume:";
            // 
            // diameterLbl
            // 
            this.diameterLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.diameterLbl.Location = new System.Drawing.Point(98, 201);
            this.diameterLbl.Name = "diameterLbl";
            this.diameterLbl.Size = new System.Drawing.Size(100, 23);
            this.diameterLbl.TabIndex = 5;
            // 
            // surfaceLbl
            // 
            this.surfaceLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.surfaceLbl.Location = new System.Drawing.Point(98, 252);
            this.surfaceLbl.Name = "surfaceLbl";
            this.surfaceLbl.Size = new System.Drawing.Size(100, 23);
            this.surfaceLbl.TabIndex = 6;
            // 
            // volumeLbl
            // 
            this.volumeLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.volumeLbl.Location = new System.Drawing.Point(98, 302);
            this.volumeLbl.Name = "volumeLbl";
            this.volumeLbl.Size = new System.Drawing.Size(100, 23);
            this.volumeLbl.TabIndex = 7;
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(272, 100);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(75, 23);
            this.calculateBtn.TabIndex = 8;
            this.calculateBtn.Text = "Calculate";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // topImage
            // 
            this.topImage.Image = ((System.Drawing.Image)(resources.GetObject("topImage.Image")));
            this.topImage.Location = new System.Drawing.Point(23, 29);
            this.topImage.Name = "topImage";
            this.topImage.Size = new System.Drawing.Size(150, 150);
            this.topImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.topImage.TabIndex = 9;
            this.topImage.TabStop = false;
            // 
            // bottomImage
            // 
            this.bottomImage.Image = ((System.Drawing.Image)(resources.GetObject("bottomImage.Image")));
            this.bottomImage.Location = new System.Drawing.Point(222, 185);
            this.bottomImage.Name = "bottomImage";
            this.bottomImage.Size = new System.Drawing.Size(150, 150);
            this.bottomImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bottomImage.TabIndex = 10;
            this.bottomImage.TabStop = false;
            // 
            // radiusTxt
            // 
            this.radiusTxt.Location = new System.Drawing.Point(273, 56);
            this.radiusTxt.Name = "radiusTxt";
            this.radiusTxt.Size = new System.Drawing.Size(100, 20);
            this.radiusTxt.TabIndex = 11;
            // 
            // labForm
            // 
            this.AcceptButton = this.calculateBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 361);
            this.Controls.Add(this.radiusTxt);
            this.Controls.Add(this.bottomImage);
            this.Controls.Add(this.topImage);
            this.Controls.Add(this.calculateBtn);
            this.Controls.Add(this.volumeLbl);
            this.Controls.Add(this.surfaceLbl);
            this.Controls.Add(this.diameterLbl);
            this.Controls.Add(this.showVolumeLbl);
            this.Controls.Add(this.showSurfaceLbl);
            this.Controls.Add(this.showDiameterLbl);
            this.Controls.Add(this.nameLbl);
            this.Name = "labForm";
            this.Text = "Lab 3";
            ((System.ComponentModel.ISupportInitialize)(this.topImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bottomImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label showDiameterLbl;
        private System.Windows.Forms.Label showSurfaceLbl;
        private System.Windows.Forms.Label showVolumeLbl;
        private System.Windows.Forms.Label diameterLbl;
        private System.Windows.Forms.Label surfaceLbl;
        private System.Windows.Forms.Label volumeLbl;
        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.PictureBox topImage;
        private System.Windows.Forms.PictureBox bottomImage;
        private System.Windows.Forms.TextBox radiusTxt;
    }
}

