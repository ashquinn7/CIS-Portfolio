﻿// Grading ID: A7035
// Lab Number: Lab 6
// Due Date: 10/28/2018
// Course Section: CIS199-01
// This Lab can calculate a student's grade based on how many words they type per minute
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // This event handler will calculate a student's grade based on how many words they type per minute
        private void enterBtn_Click(object sender, EventArgs e)
        {
            int wordsTyped; // How many words the user typed
            int[] wordsPerMinute = new int[] { 1, 16, 31, 51, 76 }; // range for words per minute
            char[] letterGrade = new char[] {'F', 'D', 'C', 'B', 'A' }; // range for grades given
            bool found = false; // returns the value as true or false based on the input
            char gradeEarned; // letter grade is given as an output

            int.TryParse(wordsTypedTxt.Text, out wordsTyped); // Reads the input and checks for errors

            int index = wordsPerMinute.Length - 1; // starts from the end since we are testing lower limits

            // This while loop tests in that the index is greater than or equal to zero and that it returns the boolean true or false
            while (index >= 0 && !found)
            {
                // Tests to make sure words typed is withing the index
                if (wordsTyped >= wordsPerMinute[index])
                {
                    found = true;
                }
                else
                    --index;
            }
            // If the boolean value is true, the grade is displayed in the label, if not, an invalid input message will appear in a message box
            if (found)
            {
                gradeEarned = letterGrade[index];
                gradeLbl.Text = $"{gradeEarned}"; // The correct output is displayed in the label
            }
            else
            {
                MessageBox.Show("Invalid Input"); // An invalid output is displayed as a message box
            }
        }

        // This event handler will clear anything in the textbook or output label
        private void clearBtn_Click(object sender, EventArgs e)
        {
            wordsTypedTxt.Text = ""; // Erases everything in the textbox
            gradeLbl.Text = ""; // Erases everything in the label
        }
    }
}
