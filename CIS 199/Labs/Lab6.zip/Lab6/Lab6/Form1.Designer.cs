﻿namespace Lab6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.typedLbl = new System.Windows.Forms.Label();
            this.wordsTypedTxt = new System.Windows.Forms.TextBox();
            this.gradeReceivedLbl = new System.Windows.Forms.Label();
            this.gradeLbl = new System.Windows.Forms.Label();
            this.enterBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // typedLbl
            // 
            this.typedLbl.AutoSize = true;
            this.typedLbl.Location = new System.Drawing.Point(40, 47);
            this.typedLbl.Name = "typedLbl";
            this.typedLbl.Size = new System.Drawing.Size(154, 13);
            this.typedLbl.TabIndex = 0;
            this.typedLbl.Text = "Enter Number of Words Typed:";
            // 
            // wordsTypedTxt
            // 
            this.wordsTypedTxt.Location = new System.Drawing.Point(205, 47);
            this.wordsTypedTxt.Name = "wordsTypedTxt";
            this.wordsTypedTxt.Size = new System.Drawing.Size(100, 20);
            this.wordsTypedTxt.TabIndex = 1;
            // 
            // gradeReceivedLbl
            // 
            this.gradeReceivedLbl.AutoSize = true;
            this.gradeReceivedLbl.Location = new System.Drawing.Point(43, 111);
            this.gradeReceivedLbl.Name = "gradeReceivedLbl";
            this.gradeReceivedLbl.Size = new System.Drawing.Size(88, 13);
            this.gradeReceivedLbl.TabIndex = 2;
            this.gradeReceivedLbl.Text = "Grade Received:";
            // 
            // gradeLbl
            // 
            this.gradeLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gradeLbl.Location = new System.Drawing.Point(205, 111);
            this.gradeLbl.Name = "gradeLbl";
            this.gradeLbl.Size = new System.Drawing.Size(100, 23);
            this.gradeLbl.TabIndex = 3;
            // 
            // enterBtn
            // 
            this.enterBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.enterBtn.Location = new System.Drawing.Point(67, 225);
            this.enterBtn.Name = "enterBtn";
            this.enterBtn.Size = new System.Drawing.Size(75, 23);
            this.enterBtn.TabIndex = 4;
            this.enterBtn.Text = "Enter";
            this.enterBtn.UseVisualStyleBackColor = true;
            this.enterBtn.Click += new System.EventHandler(this.enterBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearBtn.Location = new System.Drawing.Point(205, 224);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 5;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.enterBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearBtn;
            this.ClientSize = new System.Drawing.Size(354, 344);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.enterBtn);
            this.Controls.Add(this.gradeLbl);
            this.Controls.Add(this.gradeReceivedLbl);
            this.Controls.Add(this.wordsTypedTxt);
            this.Controls.Add(this.typedLbl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label typedLbl;
        private System.Windows.Forms.TextBox wordsTypedTxt;
        private System.Windows.Forms.Label gradeReceivedLbl;
        private System.Windows.Forms.Label gradeLbl;
        private System.Windows.Forms.Button enterBtn;
        private System.Windows.Forms.Button clearBtn;
    }
}

