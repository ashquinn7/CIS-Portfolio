﻿// Grading ID: A7035
// Lab Number: Lab 5
// Due Date: 10/21/2018
// Course Section: CIS199-01
// This lab will display astricks in four different patterns
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MAX_ROWS = 10; // Constant int for the total number of rows that will be displayed

            {
                // Pattern A
                Console.Write("Pattern A"); // Displays the name "Pattern A"
                Console.WriteLine(); // Creates a space between Pattern A and the code
                Console.WriteLine(); // Creates another space between Pattern A and the code
                // This for loop creates a single star in the first row, then adds one star per row, creating ten stars at the last row
                for (int row = 1; row <= MAX_ROWS; row++)
                {
                    for (int star = 1; star <= row; star++)
                        Console.Write("*"); // Displays an asterisk
                    Console.WriteLine(); // Creates a space between my code and the next pattern
                }
            }

            {
                // Pattern B
                Console.Write("Pattern B"); // Displays the name "Pattern B"
                Console.WriteLine(); // Creates a space between Pattern B and the code
                Console.WriteLine(); // Creates another space between Pattern B and the code
                // This for loop creates ten stars in the first row, then takes away one star per row, leaving one star in the last row
                for (int row = MAX_ROWS; row >= 1; --row)
                {
                    for (int star = 1; star <= row; star++)
                        Console.Write("*"); // Displays an asterisk
                    Console.WriteLine(); // Creates a space between my code and the next pattern
                }
            }

            {
                // Pattern C
                Console.Write("Pattern C"); // Displays the name "Pattern C"
                Console.WriteLine(); // Creates a space between Pattern C and the code
                Console.WriteLine(); // Creates another space between Pattern C and the code
                // This for loop creates ten stars in the first row, then takes away one star per row and adds a space per row, leaving one star and nine spaces in the last row
                for (int row = MAX_ROWS; row >= 1; --row)
                {
                    for (int spaces = 1; spaces <= MAX_ROWS - row; spaces++)
                        Console.Write(" ");
                    for (int star = 1; star <= row; star++)
                        Console.Write("*"); // Displays an asterisk
                    Console.WriteLine(); // Creates a space between my code and the next pattern
                }
            }

            {
                // Pattern D
                Console.Write("Pattern D"); // Displays the name "Pattern D"
                Console.WriteLine(); // Creates a space between Pattern D and the code
                Console.WriteLine(); // Creates another space between Pattern D and the code
                // This for loop creates one star on the right side in the first row, then adds a star and subtracts a space per row, leaving ten stars and zero spaces in the last row
                for (int row = 1; row <= MAX_ROWS; row++)
                {
                    for (int spaces = -1; spaces >= row - MAX_ROWS; --spaces)
                        Console.Write(" ");
                    for (int star = 1; star <= row; star++)
                        Console.Write("*"); // Displays an asterisk 
                    Console.WriteLine(); // Creates a space between my code and the next pattern
                }

            }
        }
    }
}
