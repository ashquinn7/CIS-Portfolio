﻿// Grading ID: A7035
// Lab Number: Lab 2
// Due Date: 9/16/2018
// Course Section: CIS 199-01
// This program allows you to enter the price of your meal, and it automatically calculates the low, medium, and high tip rates based off that specific price. This is a tip calculator.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2
{
    public partial class labTwoForm : Form
    {
        public labTwoForm()
        {
            InitializeComponent();
        }

        // This event handler will calculate the low, medium, and high tip for any priced meal.
        private void calculateBtn_Click(object sender, EventArgs e)
        {
            const double TIPRATE_LOW = .15; // This calculates my low tip rate, which is 15 percent. This will never change which is why it is a constant.
            const double TIPRATE_MEDIUM = .18; // This calculates my medium tip rate, which is 18 percent. This will never change which is why it is a constant.
            const double TIPRATE_HIGH = .20; // This calculates my high tip rate, which is 20 percent. This will never change which is why it is a constant.
            double tipLow; // This is the variable I am using to display the result of my calculation between the low tip rate multiplied by the price of the meal. This is a double since we are using currency, therefore we need two points after the decimal.
            double tipMedium; // This is the variable I am using to display the result of my calculation between the medium tip rate multiplied by the price of the meal. This is a double since we are using currency, therefore we need two points after the decimal.
            double tipHigh; // This is the variable I am using to display the result of my calculation between the high tip rate multiplied by the price of the meal. This is a double since we are using currency, therefore we need two points after the decimal.
            double userInput; // This is used as the input for my Tip calculator. When the customer types in the amount of their meal, the amount is parsed into the user input text box and the output is given for each percentage. This is a double since we are using currency, therefore we need two points after the decimal.

            userInput = double.Parse(userInputTxtBox.Text); // This is saying that my userInput, which was defined as a double, is being parsed in the user input text box. This means a customer will be able to enter in the price of their meal and it will be read in the text box as the input.

            tipLow = TIPRATE_LOW * userInput;
            tipMedium = TIPRATE_MEDIUM * userInput;
            tipHigh = TIPRATE_HIGH * userInput;

            lowLbl.Text = $"{tipLow:C}";
            mediumLbl.Text = $"{tipMedium:C}";
            highLbl.Text = $"{tipHigh:C}";
        }
    }
}
