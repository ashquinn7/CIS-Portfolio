﻿namespace Lab_2
{
    partial class labTwoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateBtn = new System.Windows.Forms.Button();
            this.priceLbl = new System.Windows.Forms.Label();
            this.percentlowLbl = new System.Windows.Forms.Label();
            this.percentmediumLbl = new System.Windows.Forms.Label();
            this.percenthighLbl = new System.Windows.Forms.Label();
            this.userInputTxtBox = new System.Windows.Forms.TextBox();
            this.lowLbl = new System.Windows.Forms.Label();
            this.mediumLbl = new System.Windows.Forms.Label();
            this.highLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(115, 232);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(96, 23);
            this.calculateBtn.TabIndex = 0;
            this.calculateBtn.Text = "Calculate Tip";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // priceLbl
            // 
            this.priceLbl.AutoSize = true;
            this.priceLbl.Location = new System.Drawing.Point(61, 13);
            this.priceLbl.Name = "priceLbl";
            this.priceLbl.Size = new System.Drawing.Size(98, 13);
            this.priceLbl.TabIndex = 1;
            this.priceLbl.Text = "Enter price of meal:";
            // 
            // percentlowLbl
            // 
            this.percentlowLbl.AutoSize = true;
            this.percentlowLbl.Location = new System.Drawing.Point(112, 65);
            this.percentlowLbl.Name = "percentlowLbl";
            this.percentlowLbl.Size = new System.Drawing.Size(30, 13);
            this.percentlowLbl.TabIndex = 2;
            this.percentlowLbl.Text = "15 %";
            // 
            // percentmediumLbl
            // 
            this.percentmediumLbl.AutoSize = true;
            this.percentmediumLbl.Location = new System.Drawing.Point(112, 104);
            this.percentmediumLbl.Name = "percentmediumLbl";
            this.percentmediumLbl.Size = new System.Drawing.Size(30, 13);
            this.percentmediumLbl.TabIndex = 3;
            this.percentmediumLbl.Text = "18 %";
            // 
            // percenthighLbl
            // 
            this.percenthighLbl.AutoSize = true;
            this.percenthighLbl.Location = new System.Drawing.Point(112, 147);
            this.percenthighLbl.Name = "percenthighLbl";
            this.percenthighLbl.Size = new System.Drawing.Size(30, 13);
            this.percenthighLbl.TabIndex = 4;
            this.percenthighLbl.Text = "20 %";
            // 
            // userInputTxtBox
            // 
            this.userInputTxtBox.Location = new System.Drawing.Point(193, 13);
            this.userInputTxtBox.Name = "userInputTxtBox";
            this.userInputTxtBox.Size = new System.Drawing.Size(100, 20);
            this.userInputTxtBox.TabIndex = 5;
            // 
            // lowLbl
            // 
            this.lowLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowLbl.Location = new System.Drawing.Point(193, 65);
            this.lowLbl.Name = "lowLbl";
            this.lowLbl.Size = new System.Drawing.Size(100, 23);
            this.lowLbl.TabIndex = 6;
            this.lowLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mediumLbl
            // 
            this.mediumLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mediumLbl.Location = new System.Drawing.Point(193, 104);
            this.mediumLbl.Name = "mediumLbl";
            this.mediumLbl.Size = new System.Drawing.Size(100, 23);
            this.mediumLbl.TabIndex = 7;
            this.mediumLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // highLbl
            // 
            this.highLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.highLbl.Location = new System.Drawing.Point(193, 147);
            this.highLbl.Name = "highLbl";
            this.highLbl.Size = new System.Drawing.Size(100, 23);
            this.highLbl.TabIndex = 8;
            this.highLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labTwoForm
            // 
            this.AcceptButton = this.calculateBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 341);
            this.Controls.Add(this.highLbl);
            this.Controls.Add(this.mediumLbl);
            this.Controls.Add(this.lowLbl);
            this.Controls.Add(this.userInputTxtBox);
            this.Controls.Add(this.percenthighLbl);
            this.Controls.Add(this.percentmediumLbl);
            this.Controls.Add(this.percentlowLbl);
            this.Controls.Add(this.priceLbl);
            this.Controls.Add(this.calculateBtn);
            this.Name = "labTwoForm";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.Label priceLbl;
        private System.Windows.Forms.Label percentlowLbl;
        private System.Windows.Forms.Label percentmediumLbl;
        private System.Windows.Forms.Label percenthighLbl;
        private System.Windows.Forms.TextBox userInputTxtBox;
        private System.Windows.Forms.Label lowLbl;
        private System.Windows.Forms.Label mediumLbl;
        private System.Windows.Forms.Label highLbl;
    }
}

