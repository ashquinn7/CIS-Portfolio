﻿// Grading ID: A7035
// Program Number: Program 1
// Due Date: 9/25/2018
// Course Section: CIS 199-01
// This Program calculates the number of gallons of paint I need to paint all of my walls.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1
{
    class Program
    {
        // This is where I will create my calculator as well as create the calculations for everything.
        static void Main(string[] args)
        {
            const double FEET_PER_GALLON = 385; // constant for the total amount of feet per gallon needed for the room.
            const double DOOR = 20; // constant for the amount of feet a door takes up. This is subtratcted from the equation.
            const double WINDOW = 15; // constant for the amount of feet a window takes up. This is subtracted from the equation.
            double perimeter; // number of perimeters the user will input.
            double height; // the total height of the room the user will input.
            double gallons;// number of gallons of paint needed for the room.
            int doors; // number of doors in the room.
            int windows; // number of windows in the room.
            int coats; // number of coats of paint the customer wants to use.

            // This shows my input for the perimeter, height, doors, windows, and coats of paint.
            Console.WriteLine("Welcome to the Handy-Dandy Paint Estimator");
            Console.Write("Enter the total length of all walls (in feet): ");
            perimeter = double.Parse(Console.ReadLine());
            Console.Write("Enter the height of the walls (in feet): ");
            height = double.Parse(Console.ReadLine());
            Console.Write("Enter the number of doors (non-neg int): ");
            doors = int.Parse(Console.ReadLine());
            Console.Write("Enter the number of windows (non-neg int): ");
            windows = int.Parse(Console.ReadLine());
            Console.Write("Enter the number of coats of paint (non-neg int): ");
            coats = int.Parse(Console.ReadLine());

            // This is how I calculated how many gallons I needed for the room.
            gallons = (((perimeter * height) - (doors * DOOR) - (windows * WINDOW)) * coats) / FEET_PER_GALLON;

            // This shows the output for how many total gallons of paint I need and how many approximate gallons of paint I need.
            Console.WriteLine($"You'll need a total of {gallons:F1} of paint.");
            Console.WriteLine($"You'll need to buy {gallons:F0}, though");









        }
    }
}
