﻿// Grading ID: A7035
// Program 4
// Due Date: 12/4/2018
// Class Section: CIS 199-01
// This Program displays which book have been checked out and returned to shelf using arrays, methods and constructors
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    // Precondition: Creates the methods and constructors needed for the main method
    // Postcondition: Looks at the array and displays what is needed
    class LibraryBook
    {
        const int YEAR = 2018; // Default value
        bool status = false; // Checks if a book is on the shelf or not

        // Precondition: Each of these must be established in the array
        // Postcondition: Asssigns get and set accessors for part of the array
        public LibraryBook(string title, string author, string publisher, int copyrightYear, string callNumber)
        {
            Title = title; // Title of book
            Author = author; // Author of book
            Publisher = publisher; // Publisher of book
            CopyrightYear = copyrightYear; // Copyright year of book
            CallNumber = callNumber; // Call number of book
        }
        public string Title
        {
            // Precondition: None
            // Postcondition: Returns the Title value stored in the backing field
            get;
            // Precondition: None
            // Postcondition: Retrives the values stored
            set;
        }
        public string Author
        {
            // Precondition: None
            // Postcondition: Returns the Author value stored in the backing field
            get;
            // Precondition: None
            // Postcondition: Retrives the values stored
            set;
        }
        public string Publisher
        {
            // Precondition: None
            // Postcondition: Returns the Publisher value stored in the backing field
            get;
            // Precondition: None
            // Postcondition: Retrives the values stored
            set;
        }
        private int copyrightYear; // Backing field 
        public int CopyrightYear
        {
            // Precondition: Private backing field must be established
            // Postcondition: Returns the CopyrightYear value stored in the backing field
            get
            {
                return copyrightYear; // returned copyrightYear value
            }

            // Precondition: The value must be a non-negative integer
            // Postcondition: Determines if the copyright value is greater than zero, if not, it is assigned the default value
            set
            {
                // Tests for a non-negative integer
                if (value >= 0)
                {
                    copyrightYear = value; // Value entered
                }
                else
                {
                    copyrightYear = YEAR; // Displays default year
                }
            }
        }
        public string CallNumber
        {
            // Precondition: None
            // Postcondition: Returns the CallNumber value stored in the backing field
            get;
            // Precondition: None
            // Postcondition: Retrives the value stored
            set;
        }

        // Precondition: Checks whether the book has been checked out or not
        // Postcondition: Method will say whether the book is checked out or not
        public void CheckOut()
        {
            status = true; // Returns bool value
        }

        // Precondition: Checks whether the book has been returned or not
        // Postcondition: Method will say whether the book is checked out or not and returns it to the shelf
        public void ReturnToShelf()
        {
            status = false; // Returns bool value
        }

        // Precondition: CheckOut() and ReturnToShelf() must be established along with a bool variable
        // Postcondition: Displays whether or not the book is checked out using a bool value
        public bool IsCheckedOut()
        {
            return status; // Returns bool value
        }

        // Precondition: Array and loop must be established along with everything else in the LibraryBook class
        // Postcondition: // Displays each array's information along with whether or not the book is checked out or on the shelf
        public override string ToString()
        {
            return $"Title : {Title}{Environment.NewLine} " +
                $"Author : {Author}{Environment.NewLine} " +
                $"Publisher : {Publisher}{Environment.NewLine} " +
                $"Copyright Year : {CopyrightYear}{Environment.NewLine} " +
                $"Call Number : {CallNumber}{Environment.NewLine} " +
                $"Checked Out : {IsCheckedOut()}{Environment.NewLine} "; // Displays everything about each book and whether or not it is checked out
        }









    }
}
