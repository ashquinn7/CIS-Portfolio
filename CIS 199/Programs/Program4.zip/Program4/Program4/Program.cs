﻿// Grading ID: A7035
// Program 4
// Due Date: 12/4/2018
// Course Section: CIS 199-01
// This Program displays books that have been checked out and returned to shelf using arrays, methods, and constructors
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    class Program
    {
        // Precondition: Must reference LibraryBook class in order to properly display the books for each method
        // Postcondition: The five books will be displayed three times while also saying whether or not the books were checked out or returned to shelf
        static void Main(string[] args)
        {
            LibraryBook LibraryBook1 = new LibraryBook("To Kill a Mockingbird", "Harper Lee", "J.B. Lippincott & Co", 1960, "A1111"); // First array
            LibraryBook LibraryBook2 = new LibraryBook("The Kite Runner", "Khaled Hosseini", "Riverhead Books", 2003, "A2222"); // Second array
            LibraryBook LibraryBook3 = new LibraryBook("The Hunger Games", "Suzanne Collins", "Scholastic", 2008, "A3333"); // Third array
            LibraryBook LibraryBook4 = new LibraryBook("Catching Fire", "Suzanne Collins", "Scholastic", 2009, "A4444"); // Fourth array
            LibraryBook LibraryBook5 = new LibraryBook("Mockingjay", "Suzanne Collins", "Scholastic", 2010, "A5555"); // Fifth array

            LibraryBook[] books = new LibraryBook[5]; // Searches array

            books[0] = LibraryBook1; // Book 1
            books[1] = LibraryBook2; // Book 2
            books[2] = LibraryBook3; // Book 3
            books[3] = LibraryBook4; // Book 4
            books[4] = LibraryBook5; // Book 5

            Console.WriteLine("Output 1"); // Displays first output
            PrintBooks(books); // Displays the array

            // Book 1 and 3 have been checked out
            LibraryBook1.CheckOut();
            LibraryBook3.CheckOut();

            Console.WriteLine("Output 2"); // Displays second output
            PrintBooks(books); // Displays the array after two books have been checked out

            // Book 1 and 3 have been returned to shelf
            LibraryBook1.ReturnToShelf(); 
            LibraryBook3.ReturnToShelf();

            Console.WriteLine("Output 3"); // Displays third output
            PrintBooks(books); // Displays the array after two books have been returned to shelf
        }

        // Precondition: Array must have set values
        // Postcondition: Displays each book in order
        static void PrintBooks(LibraryBook[] bookList)
        {
            // Loop that checks if the book is in the array
            foreach (LibraryBook currentBook in bookList)
            {
                Console.WriteLine(currentBook); //Displays each book
            }
        }
    }
}
