﻿// Grading ID: A7035
// Program Number: Program 2
// Due Date: 10/16/2018
// Course Section: CIS 199-01
// This Program will tell you when you are eligible to register for classes based on your last name and class standing
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
            freshmanRadBtn.Checked = true; // Freshman radio button is automatically checked when the form is first built
        }
        // This event handler will calculate when the student is able to register for classes
        private void calculateBtn_Click(object sender, EventArgs e)
        {
            string TIME_1 = "8:30"; //Displays registration time as 8:30
            string TIME_2 = "10:00"; // Displays registration time as 10:00
            string TIME_3 = "11:30"; // Displays registration time as 11:30
            string TIME_4 = "2:00"; // Displays registration time as 2:00
            string TIME_5 = "4:00"; // Displays registration time as 4:00

            string DAY_1 = "Friday, November 2nd"; // Displays registration date as Friday, November 2
            string DAY_2 = "Monday, November 5th"; // Displays registration date as Monday, November 5
            string DAY_3 = "Tuesday, November 6th"; // Displays registration date as Tuesday, November 6
            string DAY_4 = "Wednesday, November 7th"; // Displays registration date as Wednesday, November 7
            string DAY_5 = "Thursday, November 8th"; // Displays registration date as Thursday, November 8
            string DAY_6 = "Friday, November 9th"; // Displays registration date as Friday, November 9

            char lastName; // user inputes first letter of last name
            char.TryParse(lastNameTxt.Text, out lastName); // This parses the user input
            lastName = char.ToUpper(lastName); // Checks if letter entered is upper case

            // Checks whether the senior radio button is checked or the junior radio button is checked and assigns a time according to the first letter of a student's last name
            if (seniorRadBtn.Checked || juniorRadBtn.Checked)
            {
                // Tests first letter of a student's last name
                if(lastName <= 'D')
                {
                    timeLbl.Text = TIME_5;
                }
                else if(lastName <= 'I')
                {
                    timeLbl.Text = TIME_1;
                }
                else if(lastName <= 'O')
                {
                    timeLbl.Text = TIME_2;
                }
                else if(lastName <= 'S')
                {
                    timeLbl.Text = TIME_3;
                }
                else
                {
                    timeLbl.Text = TIME_4;
                }
             }

            // Checks whether the senior button is checked and displays the correct date based on the last names above. If the junior button is checked, it displays the correct date
            if (seniorRadBtn.Checked)
            {
                dateLbl.Text = DAY_1;
            }
            else
            {
                dateLbl.Text = DAY_2;
            }

            // Checks whether the freshman or sophomore radio buttons are checked and assigns the time according to the first letter of a student's last name
            if (freshmanRadBtn.Checked || sophomoreRadBtn.Checked)
            {
                // Tests first letter of a student's last name
                if (lastName <= 'B')
                {
                    timeLbl.Text = TIME_4;
                }
                else if (lastName <= 'D')
                {
                    timeLbl.Text = TIME_5;
                }
                else if (lastName <= 'F')
                {
                    timeLbl.Text = TIME_1;
                }
                else if (lastName <= 'I')
                {
                    timeLbl.Text = TIME_2;
                }
                else if (lastName <= 'L')
                {
                    timeLbl.Text = TIME_3;
                }
                else if (lastName <= 'O')
                {
                    timeLbl.Text = TIME_4;
                }
                else if(lastName <= 'Q')
                {
                    timeLbl.Text = TIME_5;
                }
                else if(lastName <= 'S')
                {
                    timeLbl.Text = TIME_1;
                }
                else if(lastName <= 'V')
                {
                    timeLbl.Text = TIME_2;
                }
                else if(lastName <= 'Z')
                {
                    timeLbl.Text = TIME_3;
                }
            }

            // Checks whether the sophomore button is checked and displays the correct date based on the first letter of a student's last name
            if (sophomoreRadBtn.Checked)
            {
                // Tests if the letter is between E and Q
                if (lastName <= 'Q' && lastName >= 'E')
                {
                    dateLbl.Text = DAY_3;
                }
                else
                {
                    dateLbl.Text = DAY_4;
                }
            }

            // Checks whether the freshman button is checked and displays the correct date based on the first letter of a student's last name
            if (freshmanRadBtn.Checked)
            {
                // Tests if the letter is between E and Q
                if (lastName <= 'Q' && lastName >= 'E')
                {
                    dateLbl.Text = DAY_5;
                }
                else
                {
                    dateLbl.Text = DAY_6;
                }
            }
        }

        // This event handler will clear any previous entries on the form
        private void clearBtn_Click(object sender, EventArgs e)
        {
            lastNameTxt.Text = ""; // Clears the textbox
            freshmanRadBtn.Checked = false; // Clear the freshman radio button
            sophomoreRadBtn.Checked = false; // Clears the sophomore radio button
            juniorRadBtn.Checked = false; // Clears the junior radio button
            seniorRadBtn.Checked = false; // Clears the senior radio button
            timeLbl.Text = ""; // Clears the time label
            dateLbl.Text = ""; // Clears the date label
        }
    }
}
