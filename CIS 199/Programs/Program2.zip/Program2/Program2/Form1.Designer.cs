﻿namespace Program2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateBtn = new System.Windows.Forms.Button();
            this.enterLastNameLbl = new System.Windows.Forms.Label();
            this.lastNameTxt = new System.Windows.Forms.TextBox();
            this.freshmanRadBtn = new System.Windows.Forms.RadioButton();
            this.sophomoreRadBtn = new System.Windows.Forms.RadioButton();
            this.juniorRadBtn = new System.Windows.Forms.RadioButton();
            this.seniorRadBtn = new System.Windows.Forms.RadioButton();
            this.dateLbl = new System.Windows.Forms.Label();
            this.dateRegisterLbl = new System.Windows.Forms.Label();
            this.clearBtn = new System.Windows.Forms.Button();
            this.timeRegisterLbl = new System.Windows.Forms.Label();
            this.timeLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(60, 311);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(75, 23);
            this.calculateBtn.TabIndex = 0;
            this.calculateBtn.Text = "Calculate";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // enterLastNameLbl
            // 
            this.enterLastNameLbl.AutoSize = true;
            this.enterLastNameLbl.Location = new System.Drawing.Point(12, 49);
            this.enterLastNameLbl.Name = "enterLastNameLbl";
            this.enterLastNameLbl.Size = new System.Drawing.Size(178, 13);
            this.enterLastNameLbl.TabIndex = 1;
            this.enterLastNameLbl.Text = "Enter First Letter of Your Last Name:";
            // 
            // lastNameTxt
            // 
            this.lastNameTxt.Location = new System.Drawing.Point(210, 46);
            this.lastNameTxt.Name = "lastNameTxt";
            this.lastNameTxt.Size = new System.Drawing.Size(100, 20);
            this.lastNameTxt.TabIndex = 2;
            // 
            // freshmanRadBtn
            // 
            this.freshmanRadBtn.AutoSize = true;
            this.freshmanRadBtn.Location = new System.Drawing.Point(64, 98);
            this.freshmanRadBtn.Name = "freshmanRadBtn";
            this.freshmanRadBtn.Size = new System.Drawing.Size(71, 17);
            this.freshmanRadBtn.TabIndex = 3;
            this.freshmanRadBtn.TabStop = true;
            this.freshmanRadBtn.Text = "Freshman";
            this.freshmanRadBtn.UseVisualStyleBackColor = true;
            // 
            // sophomoreRadBtn
            // 
            this.sophomoreRadBtn.AutoSize = true;
            this.sophomoreRadBtn.Location = new System.Drawing.Point(210, 98);
            this.sophomoreRadBtn.Name = "sophomoreRadBtn";
            this.sophomoreRadBtn.Size = new System.Drawing.Size(79, 17);
            this.sophomoreRadBtn.TabIndex = 4;
            this.sophomoreRadBtn.TabStop = true;
            this.sophomoreRadBtn.Text = "Sophomore";
            this.sophomoreRadBtn.UseVisualStyleBackColor = true;
            // 
            // juniorRadBtn
            // 
            this.juniorRadBtn.AutoSize = true;
            this.juniorRadBtn.Location = new System.Drawing.Point(64, 147);
            this.juniorRadBtn.Name = "juniorRadBtn";
            this.juniorRadBtn.Size = new System.Drawing.Size(53, 17);
            this.juniorRadBtn.TabIndex = 5;
            this.juniorRadBtn.TabStop = true;
            this.juniorRadBtn.Text = "Junior";
            this.juniorRadBtn.UseVisualStyleBackColor = true;
            // 
            // seniorRadBtn
            // 
            this.seniorRadBtn.AutoSize = true;
            this.seniorRadBtn.Location = new System.Drawing.Point(210, 147);
            this.seniorRadBtn.Name = "seniorRadBtn";
            this.seniorRadBtn.Size = new System.Drawing.Size(55, 17);
            this.seniorRadBtn.TabIndex = 6;
            this.seniorRadBtn.TabStop = true;
            this.seniorRadBtn.Text = "Senior";
            this.seniorRadBtn.UseVisualStyleBackColor = true;
            // 
            // dateLbl
            // 
            this.dateLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateLbl.Location = new System.Drawing.Point(210, 207);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(143, 23);
            this.dateLbl.TabIndex = 7;
            // 
            // dateRegisterLbl
            // 
            this.dateRegisterLbl.AutoSize = true;
            this.dateRegisterLbl.Location = new System.Drawing.Point(57, 207);
            this.dateRegisterLbl.Name = "dateRegisterLbl";
            this.dateRegisterLbl.Size = new System.Drawing.Size(104, 13);
            this.dateRegisterLbl.TabIndex = 8;
            this.dateRegisterLbl.Text = "Date of Registration:";
            // 
            // clearBtn
            // 
            this.clearBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearBtn.Location = new System.Drawing.Point(210, 311);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 9;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // timeRegisterLbl
            // 
            this.timeRegisterLbl.AutoSize = true;
            this.timeRegisterLbl.Location = new System.Drawing.Point(57, 259);
            this.timeRegisterLbl.Name = "timeRegisterLbl";
            this.timeRegisterLbl.Size = new System.Drawing.Size(104, 13);
            this.timeRegisterLbl.TabIndex = 10;
            this.timeRegisterLbl.Text = "Time of Registration:";
            // 
            // timeLbl
            // 
            this.timeLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timeLbl.Location = new System.Drawing.Point(210, 258);
            this.timeLbl.Name = "timeLbl";
            this.timeLbl.Size = new System.Drawing.Size(143, 23);
            this.timeLbl.TabIndex = 11;
            // 
            // Program2
            // 
            this.AcceptButton = this.calculateBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearBtn;
            this.ClientSize = new System.Drawing.Size(389, 367);
            this.Controls.Add(this.timeLbl);
            this.Controls.Add(this.timeRegisterLbl);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.dateRegisterLbl);
            this.Controls.Add(this.dateLbl);
            this.Controls.Add(this.seniorRadBtn);
            this.Controls.Add(this.juniorRadBtn);
            this.Controls.Add(this.sophomoreRadBtn);
            this.Controls.Add(this.freshmanRadBtn);
            this.Controls.Add(this.lastNameTxt);
            this.Controls.Add(this.enterLastNameLbl);
            this.Controls.Add(this.calculateBtn);
            this.Name = "Program2";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.Label enterLastNameLbl;
        private System.Windows.Forms.TextBox lastNameTxt;
        private System.Windows.Forms.RadioButton freshmanRadBtn;
        private System.Windows.Forms.RadioButton sophomoreRadBtn;
        private System.Windows.Forms.RadioButton juniorRadBtn;
        private System.Windows.Forms.RadioButton seniorRadBtn;
        private System.Windows.Forms.Label dateLbl;
        private System.Windows.Forms.Label dateRegisterLbl;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Label timeRegisterLbl;
        private System.Windows.Forms.Label timeLbl;
    }
}

